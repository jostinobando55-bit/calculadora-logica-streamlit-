import itertools
import re
import streamlit as st

st.set_page_config(page_title="Calculadora lógica", page_icon="🧠", layout="centered")
st.title("🧠 Calculadora lógica")
st.write("Escribe una expresión proposicional y genera su tabla de verdad.")

st.markdown("""
**Operadores:** ¬ negación · ∧ conjunción · ∨ disyunción · ⊕ XOR · → condicional · ↔ bicondicional

También se aceptan `!`, `&`, `|`, `^`, `->` y `<->`.
""")

TOKEN_RE = re.compile(r"<->|->|[A-Za-z][A-Za-z0-9_]*|[¬!∧&∨|⊕^→↔()]")
ALIASES = {
    "¬": "NOT", "!": "NOT", "∧": "AND", "&": "AND",
    "∨": "OR", "|": "OR", "⊕": "XOR", "^": "XOR",
    "→": "IMP", "->": "IMP", "↔": "IFF", "<->": "IFF",
    "(": "LP", ")": "RP"
}
PREC = {"IFF": 1, "IMP": 2, "OR": 3, "XOR": 4, "AND": 5, "NOT": 6}


class ExprError(Exception):
    pass


def tokenize(s):
    result, i = [], 0
    while i < len(s):
        if s[i].isspace():
            i += 1
            continue
        m = TOKEN_RE.match(s, i)
        if not m:
            raise ExprError(f"Carácter no válido: {s[i]!r}")
        raw = m.group()
        upper = raw.upper()
        if upper in ("AND", "OR", "NOT", "XOR"):
            result.append(("OP", upper))
        elif raw in ALIASES:
            kind = ALIASES[raw]
            result.append(("LP" if kind == "LP" else "RP", raw) if kind in ("LP", "RP") else ("OP", kind))
        else:
            result.append(("VAR", raw))
        i = m.end()
    if not result:
        raise ExprError("Escribe una expresión lógica.")
    return result


def make_rpn(tokens):
    out, ops = [], []
    previous = None
    for kind, val in tokens:
        if kind == "VAR":
            if previous in ("VAR", "RP"):
                raise ExprError("Falta un operador entre elementos.")
            out.append((kind, val))
            previous = "VAR"
        elif kind == "LP":
            if previous in ("VAR", "RP"):
                raise ExprError("Falta un operador antes del paréntesis.")
            ops.append((kind, val))
            previous = "LP"
        elif kind == "RP":
            if previous in (None, "OP", "LP"):
                raise ExprError("Revisa los paréntesis.")
            while ops and ops[-1][0] != "LP":
                out.append(ops.pop())
            if not ops:
                raise ExprError("Hay un paréntesis de cierre sin apertura.")
            ops.pop()
            previous = "RP"
        else:
            if previous in (None, "OP", "LP") and val != "NOT":
                raise ExprError("Falta una condición antes del operador.")
            if previous in ("VAR", "RP") and val == "NOT":
                raise ExprError("La negación debe colocarse antes de una condición.")
            while ops and ops[-1][0] == "OP":
                top = ops[-1][1]
                if PREC[top] > PREC[val] or (PREC[top] == PREC[val] and val != "NOT"):
                    out.append(ops.pop())
                else:
                    break
            ops.append(("OP", val))
            previous = "OP"
    if previous in ("OP", "LP"):
        raise ExprError("La expresión está incompleta.")
    while ops:
        item = ops.pop()
        if item[0] == "LP":
            raise ExprError("Falta cerrar un paréntesis.")
        out.append(item)
    return out


def evaluate(rpn, values):
    stack = []
    for kind, val in rpn:
        if kind == "VAR":
            stack.append(values[val])
        elif val == "NOT":
            if not stack:
                raise ExprError("Expresión incompleta.")
            stack.append(not stack.pop())
        else:
            if len(stack) < 2:
                raise ExprError("Expresión incompleta.")
            b, a = stack.pop(), stack.pop()
            if val == "AND":
                stack.append(a and b)
            elif val == "OR":
                stack.append(a or b)
            elif val == "XOR":
                stack.append(a != b)
            elif val == "IMP":
                stack.append((not a) or b)
            elif val == "IFF":
                stack.append(a == b)
    if len(stack) != 1:
        raise ExprError("No se pudo interpretar la expresión.")
    return stack[0]


def truth_table(expression):
    tokens = tokenize(expression)
    rpn = make_rpn(tokens)
    variables = sorted({v for k, v in tokens if k == "VAR"})
    if len(variables) > 8:
        raise ExprError("Usa como máximo 8 variables.")
    rows = []
    for values in itertools.product([True, False], repeat=len(variables)):
        assignment = dict(zip(variables, values))
        rows.append((assignment, evaluate(rpn, assignment)))
    return variables, rows


examples = ["p ∧ q", "¬p ∨ q", "(p → q) ∧ ¬r", "¬(p → ¬q) → q"]
choice = st.selectbox("Ejemplos", ["— Selecciona —"] + examples)
default = "¬(p → ¬q) → q"
expression = st.text_input("Expresión lógica", value=default if choice == "— Selecciona —" else choice)

if st.button("Generar tabla de verdad", type="primary", use_container_width=True):
    try:
        variables, rows = truth_table(expression)
        st.session_state["variables"] = variables
        st.session_state["rows"] = rows
        st.session_state["expression"] = expression
        st.session_state.pop("error", None)
    except ExprError as e:
        st.session_state.pop("rows", None)
        st.session_state["error"] = str(e)

if "error" in st.session_state:
    st.error(st.session_state["error"])

if "rows" in st.session_state:
    variables = st.session_state["variables"]
    rows = st.session_state["rows"]
    table = []
    results = []
    for assignment, result in rows:
        table.append({v: ("V" if assignment[v] else "F") for v in variables} |
                     {"Resultado": "V" if result else "F"})
        results.append(result)

    st.subheader("Tabla de verdad")
    st.caption(f"Expresión: {st.session_state['expression']}")
    st.dataframe(table, use_container_width=True, hide_index=True)

    if all(results):
        st.success("Tautología: todos los resultados son verdaderos.")
    elif not any(results):
        st.warning("Contradicción: todos los resultados son falsos.")
    else:
        st.info("Contingencia: existen resultados verdaderos y falsos.")

    csv_text = ",".join(variables + ["Resultado"]) + "\n"
    csv_text += "\n".join(",".join(row[v] for v in variables + ["Resultado"]) for row in table)
    st.download_button("Descargar tabla en CSV", csv_text, "tabla_de_verdad.csv", "text/csv",
                       use_container_width=True)

st.divider()
st.caption("Calculadora de lógica proposicional")
